package q4;

class Station extends Thread {
    private final String name;
    private final int scripts;

    Station(String name, int scripts) {
        this.name = name;
        this.scripts = scripts;
    }

    @Override
    public void run() {
        try {
            for (int i = 1; i <= scripts; i++) {
                Thread.sleep(100);   // simulate scanning
            }
            System.out.println(name + " finished. Scanned " + scripts + " scripts.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
public class ScannerStationDemo {
	public static void main(String[] args) throws InterruptedException {
        Station s1 = new Station("Station-1", 5);
        Station s2 = new Station("Station-2", 5);
        Station s3 = new Station("Station-3", 5);
        Station s4 = new Station("Station-4", 5);

        s1.start();
        s2.start();
        s3.start();
        s4.start();

        s1.join();
        s2.join();
        s3.join();
        s4.join();

        System.out.println("All stations finished. Total scripts processed.");
    }

}
