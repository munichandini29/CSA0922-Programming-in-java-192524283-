package q7;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

public class ResultProcessor {
	static class Result {
        final boolean success;
        final String message;

        Result(boolean success, String message) {
            this.success = success;
            this.message = message;
        }
    }

    static Result processFile(String fileName) {
        // Simulate processing
        if (fileName.contains("corrupt") || fileName.contains("missing")) {
            return new Result(false, "Failed: " + fileName);
        }
        return new Result(true, "OK: " + fileName);
    }

    public static void main(String[] args) throws InterruptedException {
        List<String> files = new ArrayList<>();
        for (int i = 1; i <= 20; i++) {
            files.add("script" + i + ".txt");
        }
        files.add("corrupt_file.txt");
        files.add("missing_file.txt");

        ExecutorService pool = Executors.newFixedThreadPool(4);
        List<Future<Result>> futures = new ArrayList<>();

        for (String f : files) {
            futures.add(pool.submit(() -> processFile(f)));
        }

        int success = 0, failure = 0;
        for (Future<Result> fut : futures) {
            try {
                Result r = fut.get();
                if (r.success) success++;
                else {
                    failure++;
                    System.out.println(r.message);
                }
            } catch (ExecutionException e) {
                failure++;
                System.out.println("Unexpected error: " + e.getCause());
            }
        }

        pool.shutdown();
        System.out.println("Success: " + success + "  Failure: " + failure);
    }

}
