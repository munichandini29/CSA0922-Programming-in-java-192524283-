package q3;
import java.io.*;

public class ReportGenerator {
	public static void manualVersion(String[] storeFiles) {
        BufferedReader br = null;
        try {
            for (String file : storeFiles) {
                br = new BufferedReader(new FileReader(file));
                String line;
                while ((line = br.readLine()) != null) {
                    System.out.println("Processing: " + line);
                }
                br.close();   // may be skipped if exception occurs
            }
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Version 2 – try-with-resources (safe)
    public static void tryWithResourcesVersion(String[] storeFiles) {
        for (String file : storeFiles) {
            try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = br.readLine()) != null) {
                    System.out.println("Processing: " + line);
                }
            } catch (IOException e) {
                System.out.println("Error in file " + file + ": " + e.getMessage());
            }
        }
    }

    public static void main(String[] args) {
        // Create a couple of dummy files for testing or use existing ones
        String[] files = {"store1.txt", "store2.txt", "missing.txt"};
        System.out.println("--- try-with-resources version ---");
        tryWithResourcesVersion(files);
    }

}
