package q1;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.Scanner;

class InsufficientFundsException extends Exception {
    public InsufficientFundsException(String message) {
        super(message);
    }
}

public class ATMSimulation {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double balance = 5000.0;

        try {
            System.out.print("Enter account number: ");
            int accNo = sc.nextInt();

            System.out.print("Enter withdrawal amount: ");
            double amount = sc.nextDouble();

            if (amount <= 0) {
                throw new IllegalArgumentException("Amount must be positive");
            }

            // Simulate card file check
            File cardFile = new File("card_" + accNo + ".dat");
            if (!cardFile.exists()) {
                throw new FileNotFoundException("Card data file not found");
            }

            if (amount > balance) {
                throw new InsufficientFundsException("Insufficient balance. Available: " + balance);
            }

            balance -= amount;
            System.out.println("Please collect your cash: " + amount);
            System.out.println("Remaining balance: " + balance);

        } catch (InputMismatchException e) {
            System.out.println("Error: Please enter numbers only");
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (InsufficientFundsException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (FileNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Unexpected error: " + e.getMessage());
        } finally {
            System.out.println("Transaction ended. Thank you!");
            sc.close();
        }
    }

}
