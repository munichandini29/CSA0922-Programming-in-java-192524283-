package task_3;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class LibrarySearch extends JFrame {
	public LibrarySearch() {
        super("Campus Library Search");

        // NORTH – search row (FlowLayout)
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.add(new JLabel("Search:"));
        searchPanel.add(new JTextField(15));
        searchPanel.add(new JComboBox<>(new String[]{"All", "Books", "Journals"}));
        searchPanel.add(new JButton("Search"));

        // CENTER – results area (grows when resized)
        JTextArea results = new JTextArea(10, 40);
        results.setText("Results will appear here...");
        JScrollPane scroll = new JScrollPane(results);

        // SOUTH – buttons + status
        JPanel bottom = new JPanel(new BorderLayout());
        JPanel buttons = new JPanel(new FlowLayout());
        buttons.add(new JButton("Prev"));
        buttons.add(new JButton("Next"));
        buttons.add(new JButton("Reserve"));
        bottom.add(buttons, BorderLayout.CENTER);
        bottom.add(new JLabel(" Status: Ready"), BorderLayout.SOUTH);

        add(searchPanel, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);

        setSize(500, 350);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LibrarySearch().setVisible(true));
    }

}
