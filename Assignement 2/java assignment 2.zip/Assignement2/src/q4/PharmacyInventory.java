package q4;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class PharmacyInventory {
	public static void main(String[] args) {
        Map<String, Integer> hashMap = new HashMap<>();
        Map<String, Integer> treeMap = new TreeMap<>();
        Map<String, Integer> linkedHashMap = new LinkedHashMap<>();

        // Insert some medicines
        String[] codes = {"MED103", "MED101", "MED105", "MED102", "MED104"};
        for (String code : codes) {
            hashMap.put(code, 50);
            treeMap.put(code, 50);
            linkedHashMap.put(code, 50);
        }

        System.out.println("HashMap order      : " + hashMap.keySet());
        System.out.println("TreeMap order      : " + treeMap.keySet());
        System.out.println("LinkedHashMap order: " + linkedHashMap.keySet());
    }
	
	

}
