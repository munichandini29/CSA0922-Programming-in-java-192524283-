package q1;

public class TicketBuilder {
	public static void main(String[] args) {
        int fields = 50;
        int tickets = 5000;

        // Workload
        String[] data = new String[fields];
        for (int i = 0; i < fields; i++) {
            data[i] = "Field" + i;
        }

        // ---------- 1. Using String + ----------
        long start = System.nanoTime();
        for (int t = 0; t < tickets; t++) {
            String ticket = "";
            for (String f : data) {
                ticket = ticket + f + "|";
            }
        }
        long timeString = (System.nanoTime() - start) / 1_000_000;
        System.out.println("String + time       : " + timeString + " ms");

        // ---------- 2. Using StringBuilder ----------
        start = System.nanoTime();
        for (int t = 0; t < tickets; t++) {
            StringBuilder sb = new StringBuilder();
            for (String f : data) {
                sb.append(f).append("|");
            }
            String ticket = sb.toString();
        }
        long timeBuilder = (System.nanoTime() - start) / 1_000_000;
        System.out.println("StringBuilder time  : " + timeBuilder + " ms");

        // ---------- 3. Using StringBuffer ----------
        start = System.nanoTime();
        for (int t = 0; t < tickets; t++) {
            StringBuffer sbf = new StringBuffer();
            for (String f : data) {
                sbf.append(f).append("|");
            }
            String ticket = sbf.toString();
        }
        long timeBuffer = (System.nanoTime() - start) / 1_000_000;
        System.out.println("StringBuffer time   : " + timeBuffer + " ms");
    }

}