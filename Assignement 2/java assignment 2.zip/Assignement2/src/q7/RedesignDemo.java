package q7;

public class RedesignDemo {
	public static void main(String[] args) {
        int fields = 100;
        int tickets = 3000;

        String[] data = new String[fields];
        for (int i = 0; i < fields; i++) data[i] = "F" + i;

        // Original slow way
        long start = System.nanoTime();
        for (int t = 0; t < tickets; t++) {
            String ticket = "";
            for (String f : data) ticket = ticket + f + "|";
        }
        long oldTime = (System.nanoTime() - start) / 1_000_000;

        // Redesigned way
        start = System.nanoTime();
        for (int t = 0; t < tickets; t++) {
            StringBuilder sb = new StringBuilder(fields * 10);
            for (String f : data) sb.append(f).append("|");
            String ticket = sb.toString();
        }
        long newTime = (System.nanoTime() - start) / 1_000_000;

        System.out.println("Original String + time : " + oldTime + " ms");
        System.out.println("Redesigned SB time     : " + newTime + " ms");
        System.out.println("Speed-up               : " + (oldTime / (newTime + 1)) + " times faster");
    }

}
