package q2;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class PlaylistTest {
	public static void main(String[] args) {
        int size = 50000;

        List<String> arrayList = new ArrayList<>();
        List<String> linkedList = new LinkedList<>();

        // Add at end
        long start = System.nanoTime();
        for (int i = 0; i < size; i++) arrayList.add("Song" + i);
        System.out.println("ArrayList  add end   : " + (System.nanoTime() - start) / 1_000_000 + " ms");

        start = System.nanoTime();
        for (int i = 0; i < size; i++) linkedList.add("Song" + i);
        System.out.println("LinkedList add end   : " + (System.nanoTime() - start) / 1_000_000 + " ms");

        // Insert at beginning
        start = System.nanoTime();
        for (int i = 0; i < 1000; i++) arrayList.add(0, "New");
        System.out.println("ArrayList  insert front: " + (System.nanoTime() - start) / 1_000_000 + " ms");

        start = System.nanoTime();
        for (int i = 0; i < 1000; i++) linkedList.add(0, "New");
        System.out.println("LinkedList insert front: " + (System.nanoTime() - start) / 1_000_000 + " ms");

        // Random access
        start = System.nanoTime();
        for (int i = 0; i < 10000; i++) arrayList.get(i % arrayList.size());
        System.out.println("ArrayList  get(k)    : " + (System.nanoTime() - start) / 1_000_000 + " ms");

        start = System.nanoTime();
        for (int i = 0; i < 10000; i++) linkedList.get(i % linkedList.size());
        System.out.println("LinkedList get(k)    : " + (System.nanoTime() - start) / 1_000_000 + " ms");
    }
}
