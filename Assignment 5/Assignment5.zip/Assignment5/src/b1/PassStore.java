package b1;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;

public class PassStore {
	private final Path file;

    public PassStore(Path file) {
        this.file = file;
    }

    public void add(String passId, String regNo, String name, int route, double amount)
            throws IOException {
        try (BufferedWriter w = Files.newBufferedWriter(file,
                StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
            w.write(String.join(",", passId, regNo, name,
                    String.valueOf(route), String.valueOf(amount)));
            w.newLine();
        }
    }

    public String[] find(String passId) throws IOException {
        try (BufferedReader r = Files.newBufferedReader(file)) {
            String line;
            while ((line = r.readLine()) != null) {
                String[] fields = line.split(",", -1);
                if (fields.length != 5) {
                    continue;               // skip damaged line
                }
                if (fields[0].equals(passId)) {
                    return fields;
                }
            }
        }
        return null;
    }

    public static void main(String[] args) throws IOException {
        Path f = Files.createTempFile("passes", ".csv");
        PassStore store = new PassStore(f);

        // Normal records
        store.add("P1001", "192311001", "Arun", 12, 4500);
        store.add("P1003", "192311003", "Divya", 7, 3800);

        // Damaged line (as required in assignment)
        Files.writeString(f, "P1002,DAMAGED LINE\n", StandardOpenOption.APPEND);

        System.out.println("=== Searching for P1003 ===");
        System.out.println(Arrays.toString(store.find("P1003")));

        System.out.println("\n=== Searching for damaged P1002 ===");
        System.out.println(Arrays.toString(store.find("P1002")));

        System.out.println("\n=== Searching for non-existing P9999 ===");
        System.out.println(Arrays.toString(store.find("P9999")));

        Files.delete(f);
        System.out.println("\nProgram finished successfully.");
    }

}
