package b3;
import java.util.ArrayList;
import java.util.List;
public class BatchDemo {
	public static void main(String[] args) {
        List<String[]> passes = new ArrayList<>();
        passes.add(new String[]{"P1001", "192311001", "Arun", "12", "4500"});
        passes.add(new String[]{"P1002", "192311002", "Priya", "5", "3200"});
        passes.add(new String[]{"P1003", "192311003", "Divya", "7", "3800"});
        passes.add(new String[]{"P1004", "192311004", "Rahul", "3", "4100"});
        passes.add(new String[]{"P1005", "192311005", "Sneha", "9", "2900"});

        System.out.println("=== Simulating Batch Insert (1000 rows batch) ===");
        System.out.println("Auto-commit = false (using transaction)");

        int count = 0;
        for (String[] p : passes) {
            count++;
            System.out.println("Added to batch: " + p[0] + " - " + p[2]);

            if (count % 1000 == 0) {
                System.out.println(">>> executeBatch() called");
            }
        }

        System.out.println(">>> Final executeBatch()");
        System.out.println(">>> COMMIT successful");
        System.out.println("\nTotal records loaded: " + count);
        System.out.println("All records committed in one transaction.");
    }

}
